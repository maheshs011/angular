import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bayc',
  templateUrl: './bayc.component.html',
  styleUrls: ['./bayc.component.css']
})
export class BaycComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

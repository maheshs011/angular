import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-genesis',
  templateUrl: './genesis.component.html',
  styleUrls: ['./genesis.component.css']
})
export class GenesisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-temple',
  templateUrl: './temple.component.html',
  styleUrls: ['./temple.component.css']
})
export class TempleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-void',
  templateUrl: './void.component.html',
  styleUrls: ['./void.component.css']
})
export class VoidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
